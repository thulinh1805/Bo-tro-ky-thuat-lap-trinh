#include<iostream>
using namespace std;
int main(){
    int n,a[100];
    cout<<"\nNhap so luong mang: ";
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
    for(int i=0;i<n;i++){
        cout<<"\na["<<i<<"]="<<a[i];
    }

    return 0;

}
