#include<iostream>
using namespace std;
int main(){
    int max,vt,n,a[50],S=0,dem=0,tg;
    cout<<"\nNhap so luong mang: ";
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
    for(int i=0;i<n;i++){
        cout<<"\na["<<i<<"]="<<a[i];
    }
    max=a[0];
    for(int i=1;i<n;i++){
        if(a[i]>=max)
            max=a[i];
            vt=i;
    }
    cout<<"\nMax la: "<<max;
    cout<<"\nVi tri max: "<<vt<<endl;
    cout<<"Sap xep: ";
    for(int i=0;i<n;i++){
        for(int j=i+1;j<n;j++){
            if(a[i]>=a[j]){
                tg=a[i];
                a[i]=a[j];
                a[j]=tg;
            }
        }
    }
    for(int i=0;i<n;i++){
    cout<<a[i]<<"   ";
    }

    for(int i=0;i<n;i++){
        S+=a[i];
        dem++;
    }
    cout<<"\nTong la: "<<S;
    cout<<"\nTBC la: "<<((float)S/(float)dem);

        return 0;
}
