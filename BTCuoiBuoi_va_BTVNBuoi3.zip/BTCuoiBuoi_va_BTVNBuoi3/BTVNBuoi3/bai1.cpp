#include<iostream>
using namespace std;
int main(){
    int n=1,i=0,a[100];
    cout<<"Nhap cac phan tu cua mang: ";
    while(a[i]!=0){
        cin>>a[i];
        if(a[i]==0){
            a[i]=a[i-1];
            n--;
            i--;
            break;
        }
        else{
            i++;
            n++;
        }
    }
    for(int i=0;i<n;i++){
        cout<<"a["<<i<<"]="<<a[i]<<"  "<<endl;
    }

    cout<<"\nDay cac so chan la: "<<endl;
    for(int i=0;i<n;i++){
        if(a[i]%2==0)
            cout<<"   "<<a[i];
    }

    cout<<"\nDay cac so le la: "<<endl;
    for(int i=0;i<n;i++){
        if(a[i]%2!=0)
            cout<<"   "<<a[i];
    }
    int tg;
    cout<<"\nChan truoc le sau: ";
        for(int i=0;i<n;i++){
            for(int j=i+1;j<n;j++){
                if(a[j]%2==0){
                    tg=a[i];
                    a[i]=a[j];
                    a[j]=tg;
                    break;
                }
            }
        }
         for(int i=0;i<n;i++){
            cout<<" "<<a[i];
         }
    return 0;
}
