#include<iostream>
using namespace std;
int main(){
    int n1,n2,n3,n4,a1[50],a2[50],a3[50],a4[50];
    cout<<"Nhap so phan tu mang n1: ";
    cin>>n1;
    for(int i=0;i<n1;i++){
        cin>>a1[i];
    }
    cout<<"Mang n1: "<<endl;
    for(int i=0;i<n1;i++){
        cout<<"a["<<i<<"]="<<a1[i]<<endl;
    }

    cout<<"Nhap so phan tu mang n2: ";
    cin>>n2;
    for(int i=0;i<n2;i++){
        cin>>a2[i];
    }
    cout<<"Mang n2: "<<endl;
    for(int i=0;i<n2;i++){
        cout<<"a["<<i<<"]="<<a2[i]<<endl;
    }

    cout<<"Nhap so phan tu mang n3: ";
    cin>>n3;
    for(int i=0;i<n3;i++){
        cin>>a3[i];
    }
    cout<<"Mang n3: "<<endl;
    for(int i=0;i<n3;i++){
        cout<<"a["<<i<<"]="<<a3[i]<<endl;
    }

    cout<<"Nhap so phan tu mang n4: ";
    cin>>n4;
    for(int i=0;i<n4;i++){
        cin>>a4[i];
    }
    cout<<"Mang n4: "<<endl;
    for(int i=0;i<n4;i++){
        cout<<"a["<<i<<"]="<<a4[i]<<endl;
    }

    int tg;
    for(int i=0;i<n1;i++){
        for(int j=i+1;j<n1;j++){
            if(a1[i]>a1[j]){
                tg=a1[i];
                a1[i]=a1[j];
                a1[j]=tg;
            }
        }
    }
    for(int i=0;i<n1;i++){
        cout<<a1[i]<<"  ";
    }
    cout<<endl;
    for(int i=0;i<n2;i++){
        for(int j=i+1;j<n2;j++){
            if(a2[i]>a2[j]){
                tg=a2[i];
                a2[i]=a2[j];
                a2[j]=tg;
            }
        }
    }
    /*for(int i=0;i<n2;i++){
        if(a2[i]<0){
        for(int j=i+1;j<n2;j++){
            a2[j]=a2[j+1];
        }
        }
    }*/
    for(int i=0;i<n2;i++){
        cout<<a2[i]<<"  ";
    }

    cout<<endl;
    for(int i=0;i<n3;i++){
        for(int j=i+1;j<n3;j++){
            if(a3[i]>a3[j]){
                tg=a3[i];
                a3[i]=a3[j];
                a3[j]=tg;
            }
        }
    }
     for(int i=0;i<n3;i++){
        cout<<a3[i]<<"  ";
    }

    cout<<endl;
    for(int i=0;i<n4;i++){
        for(int j=i+1;j<n4;j++){
            if(a4[i]>a4[j]){
                tg=a4[i];
                a4[i]=a4[j];
                a4[j]=tg;
            }
        }
    }
     for(int i=0;i<n4;i++){
        cout<<a4[i]<<"  ";
    }
    return 0;
}
