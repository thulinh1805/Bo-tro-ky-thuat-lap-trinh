#include <iostream>
using namespace std;
int main(){
    int x,t,c,dv,T;
    do{
        cout<<"Nhap x: ";
        cin>>x;
    }while((x<=0)||(x>109));
    t= x/100;
    c= (x-(t*100))/10;
    dv=x-t*100-c*10;
    T=t+c+dv;
    cout<<"\nx= "<<x<<"\n"<<t<<"+"<<c<<"+"<<dv<<"="<<T;;

    return 0;
}

