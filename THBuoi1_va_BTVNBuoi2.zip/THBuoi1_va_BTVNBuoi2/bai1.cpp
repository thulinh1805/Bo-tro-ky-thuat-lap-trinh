#include <iostream>
#include <math.h>
using namespace std;
int main(){
    int n,S=0;
    cout<<"Nhap n: ";
    cin>>n;
    for(int i=1;i<n;i++){
        if(n%i==0){
            S+=i;
        }
    }
    if(S==n){
        cout<<n<<" la so hoan hao";
    }
    else
        cout<<n<<" khong la so hoan hao";

    return 0;
}
