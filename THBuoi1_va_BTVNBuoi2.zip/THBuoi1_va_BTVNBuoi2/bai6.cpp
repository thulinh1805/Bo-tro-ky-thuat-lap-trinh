#include <iostream>
using namespace std;
int main(){
    int n,dem=0;
    float tbc=0;
    do{
        cout<<"Nhap n: ";
        cin>>n;
    }while((n<0)||(n>50));
    for(int i=1;i<=n;i++){
        if(i%2==0){
            dem++;
            tbc+=i;
        }
    }
    tbc=tbc/dem;
    cout<<"\nTBC cac so chan la: "<<tbc;

    return 0;
}

