#include <iostream>
#include<math.h>
using namespace std;
int main(){
    int i,n,a,max=0;
    do{
    cout<<"Nhap n co 5 chu so: ";
    cin>>n;
    }while((n<10000)||(n>99999));
    while (n > 0) {
        int a = n % 10;
        n /= 10;
        if (a > max)
            max = a;
    }
    cout << "Chu so lon nhat la: " << max << endl;

    return 0;
}


