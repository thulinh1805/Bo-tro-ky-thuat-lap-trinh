#include <iostream>
using namespace std;
//B�i 1
/*int main(){
    int n;
    cout<<"Nhap n: ";
    cin>>n;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++)
            if(i==1||i==n||j==1||j==n){
                cout<<"* ";
            }
            else
                cout<<"  ";
        cout<<endl;
    }
    return 0;
}*/

//B�i 2
/*int main(){
    int n, dem=0;
    cout<<"Nhap n: ";
    cin>>n;
    for(int i=1;i<=n;i++){
        if((i%6==0)||(i%2==0)||(i%3==0))
            dem++;
    }
    cout<<dem;

    return 0;
}*/

//B�i 3
/*int main(){
    int a,b,c;
    cout<<"Nhap a, b, c: ";
    cin>>a>>b>>c;
    cout<<"Gia tri lon nhat la: "<<(a > b ? (a > c ? a : c) : (b > c ? b : c));
    return 0;
}*/

//B�i 4
int main(){
    int n,S=0;
    cout<<"Nhap n: ";
    cin>>n;
     while (n != 0) {
        S += n % 10;
        n /= 10;
    }
    cout<<S;

}

//B�i 5
/*int main(){
    int n,gt=1;
    cout<<"Nhap n: ";
    cin>>n;
    for(int i=1;i<=n;i++){
        gt=gt*i;
    }
    cout<<gt;

    return 0;

}*/

