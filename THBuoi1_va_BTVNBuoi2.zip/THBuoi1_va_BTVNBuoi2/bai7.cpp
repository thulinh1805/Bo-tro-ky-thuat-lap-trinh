#include <iostream>
using namespace std;
int main(){
    float S,V,R;
    cout<<"Nhap R: ";
    cin>>R;
    S =4*R*R;
    V=R*S/3;
    cout<<"\nDien tich la: "<<S;
    cout<<"\nThe tich la: "<<V;

    return 0;
}

