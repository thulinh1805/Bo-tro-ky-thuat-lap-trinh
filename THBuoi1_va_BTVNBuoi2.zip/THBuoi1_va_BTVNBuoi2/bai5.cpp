#include <iostream>
using namespace std;
int main(){
    int n;
    float S=0;
    cout<<"Nhap n: ";
    cin>>n;
    for(int i=0;i<=n;i++){
        S+=2*i+1;
    }
    cout<<"\nTong la: "<<S;

    return 0;
}


