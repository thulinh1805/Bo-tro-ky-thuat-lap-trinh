#include <iostream>
using namespace std;
int main(){
    int n,dem1=0,dem2=0,dem3=0,dem4=0;
    cout<<"Nhap n: ";
    cin>>n;
    while(n>=100){
        dem1+=n/100;
        n=n-dem1*100;
    }
    while(n>=50){
        dem2+=n/50;
        n=n-dem2*50;
    }
    while(n>=20){
        dem3+=n/20;
        n=n-dem3*20;
    }
    while(n>=10){
        dem4+=n/10;
        n=n-dem4*10;
    }
    cout<<"So to 100: "<<dem1<<" to"<<endl;
    cout<<"So to 50: "<<dem2<<" to"<<endl;
    cout<<"So to 20: "<<dem3<<" to"<<endl;
    cout<<"So to 10: "<<dem4<<" to";

    return 0;
}
