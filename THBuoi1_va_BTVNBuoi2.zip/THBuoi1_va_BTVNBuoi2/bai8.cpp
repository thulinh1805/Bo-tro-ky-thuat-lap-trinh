#include <iostream>
using namespace std;
int main(){
    int a,b,S=0;
    cout<<"Nhap a, b: ";
    cin>>a>>b;
    if((a<0)||(b<0)||(a>b))
        cout<<"\nMoi nhap lai!";
    else{
        for(int i=a;i<=b;i++){
            if(i%2==1){
                cout<<" "<<i;
                S+=i;
            }
        }
        cout<<"\nTong la: "<<S;
    }
    return 0;

}

