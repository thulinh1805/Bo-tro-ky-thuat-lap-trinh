#include <iostream>
using namespace std;
int main(){
    int n,dem=0;
    cout<<"Nhap n: ";
    cin>>n;
    while(n!=0){
        n=n/10;
        dem+=1;
    }
    cout<<"So luong chu so: "<<dem;

    return 0;
}

