#include<iostream>
using namespace std;
int main(){
    int a,b,c,d,s=0;
    cout<<"\nNhap 4 chu so bat ki: ";
    cin>>a>>b>>c>>d;
    s=a+b+c+d;
    if(s>=10){
        s=s%10;
        cout<<"\nHang don vi cua tong la: "<<s;
    }
    else if(s<10){
        cout<<"\nHang don vi cua tong la: "<<s;
    }

    return 0;
}
